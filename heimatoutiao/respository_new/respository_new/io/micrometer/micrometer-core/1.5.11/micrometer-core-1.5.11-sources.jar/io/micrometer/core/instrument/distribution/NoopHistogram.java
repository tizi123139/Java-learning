/**
 * Copyright 2017 VMware, Inc.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.distribution;

public class NoopHistogram implements Histogram {
    public static final NoopHistogram INSTANCE = new NoopHistogram();

    private NoopHistogram() {
    }

    @Override
    public void recordLong(long value) {
    }

    @Override
    public void recordDouble(double value) {
    }

    @Override
    public HistogramSnapshot takeSnapshot(long count, double total, double max) {
        return HistogramSnapshot.empty(count, total, max);
    }
}
