/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.hbase.client;

import org.apache.yetus.audience.InterfaceAudience;

/**
 * Scan cursor to tell client where server is scanning
 * {@link Scan#setNeedCursorResult(boolean)}
 * {@link Result#isCursor()}
 * {@link Result#getCursor()}
 */
@InterfaceAudience.Public
public class Cursor {

  private final byte[] row;

  Cursor(byte[] row) {
    this.row = row;
  }

  public byte[] getRow() {
    return row;
  }
}
